package practiceproject4;

import java.util.Arrays;

public class LongestIncreasingSubsequence {

    public static int findLongestIncreasingSubsequence(int[] nums) {
        int n = nums.length;
        int[] lis = new int[n];

        // Initialize LIS values for all indexes
        Arrays.fill(lis, 1);

        // Compute optimized LIS values in bottom-up manner
        for (int i = 1; i < n; i++)
            for (int j = 0; j < i; j++)
                if (nums[i] > nums[j] && lis[i] < lis[j] + 1)
                    lis[i] = lis[j] + 1;

        // Find the maximum value in lis array
        int maxLength = 0;
        for (int i : lis)
            maxLength = Math.max(maxLength, i);

        return maxLength;
    }

    public static void main(String[] args) {
        // Example usage
        int[] numbers = {10, 22, 9, 33, 21, 50, 41, 60};
        int length = findLongestIncreasingSubsequence(numbers);

        System.out.println("Length of the Longest Increasing Subsequence: " + length);
    }
}
