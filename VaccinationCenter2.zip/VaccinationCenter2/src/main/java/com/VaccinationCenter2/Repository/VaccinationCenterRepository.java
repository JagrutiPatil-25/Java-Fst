package com.VaccinationCenter2.Repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;


import com.VaccinationCenter2.Entities.*;

public interface VaccinationCenterRepository extends CrudRepository<VaccinationCenter, Integer> {

	List<VaccinationCenter> findByCenterName(String centerName);
	
	List<VaccinationCenter> findAll();
}