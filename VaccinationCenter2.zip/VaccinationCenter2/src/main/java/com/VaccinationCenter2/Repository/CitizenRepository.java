package com.VaccinationCenter2.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.VaccinationCenter2.Entities.*;

public interface CitizenRepository extends JpaRepository<Citizen, Integer> {

	List<Citizen> findByCenterCenterName(String centerName);

}
