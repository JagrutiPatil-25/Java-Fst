public class ConstructorType {

    // Class with a default (no-argument) constructor
    public static class DefaultConstructorExample {
        private String message;

        // Default constructor
        public DefaultConstructorExample() {
            this.message = "Default Message";
        }

        // Getter method
        public String getMessage() {
            return message;
        }
    }

    // Class with a parameterized constructor
    public static class ParameterizedConstructorExample {
        private int value;

        // Parameterized constructor
        public ParameterizedConstructorExample(int value) {
            this.value = value;
        }

        // Getter method
        public int getValue() {
            return value;
        }
    }


    public static void main(String[] args) {
        // Default constructor example
        DefaultConstructorExample defaultExample = new DefaultConstructorExample();
        System.out.println("Default Constructor Example: " + defaultExample.getMessage());

        // Parameterized constructor example
        ParameterizedConstructorExample parameterizedExample = new ParameterizedConstructorExample(42);
        System.out.println("Parameterized Constructor Example: " + parameterizedExample.getValue());
    }
}
