package Practiceproject2;

import java.util.Scanner;

public class EmailSearch{

    public static void main(String[] args) {
        // Array of email IDs
        String[] emailArray = {
            "john.doe@example.com",
            "jane.smith@example.com",
            "alice.jones@example.com",
            // Add more email IDs as needed
        };

        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter an email ID for search
        System.out.print("Enter the email ID to search: ");
        String searchEmail = scanner.nextLine();

        // Call the searchEmail method to check if the entered email is in the array
        boolean isEmailFound = searchEmail(emailArray, searchEmail);

        // Display the result based on whether the email was found or not
        if (isEmailFound) {
            System.out.println("Email ID found in the array.");
        } else {
            System.out.println("Email ID not found in the array.");
        }

        // Close the scanner
        scanner.close();
    }

    // Method to search for an email ID in the array
    private static boolean searchEmail(String[] emailArray, String searchEmail) {
        for (String email : emailArray) {
            // Compare ignoring case
            if (email.equalsIgnoreCase(searchEmail)) {
                return true; // Email ID found
            }
        }
        return false; // Email ID not found
    }
}
