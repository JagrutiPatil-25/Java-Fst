public class Array {

    public static void main(String[] args) {
        // 1D Array Example
        int[] oneDimensionalArray = {1, 2, 3, 4, 5};

        System.out.println("1D Array Elements:");
        for (int i = 0; i < oneDimensionalArray.length; i++) {
            System.out.print(oneDimensionalArray[i] + " ");
        }

        // 2D Array Example
        int[][] twoDimensionalArray = {
                {1, 2, 3},
                {4, 5, 6},
                {7, 8, 9}
        };

        System.out.println("\n\n2D Array Elements:");
        for (int row = 0; row < twoDimensionalArray.length; row++) {
            for (int col = 0; col < twoDimensionalArray[row].length; col++) {
                System.out.print(twoDimensionalArray[row][col] + " ");
            }
            System.out.println();
        }
    }
}
