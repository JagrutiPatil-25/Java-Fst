import java.util.Queue;
import java.util.LinkedList;

public class QueueEx {
	public static void main(String[] args) {
		Queue<String> cityQueue = new LinkedList<>();
		cityQueue.add("Nashik");
		cityQueue.add("Jalgaon");
		cityQueue.add("Dhule");
		cityQueue.add("Pune");
		cityQueue.add("Mumbai");
		System.out.println("Queue is : "+cityQueue);
		System.out.println("Head of Queue : "+cityQueue.peek());
		cityQueue.remove();
		System.out.println("After removing Head of Queue : "+cityQueue);
		System.out.println("Size of Queue : "+cityQueue.size());
		
	}

}
