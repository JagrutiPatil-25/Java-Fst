package com.example;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.example.Feedback;
@Repository
public interface MyRepo extends CrudRepository<Feedback, Integer>{
}