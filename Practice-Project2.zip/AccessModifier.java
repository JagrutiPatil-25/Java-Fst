// AccessModifierExample.java

// Public class with public access modifier
public class AccessModifier {
    // Public field
    public int publicNumber = 10;

    // Private field
    private int privateNumber = 20;

    // Protected field
    protected int protectedNumber = 30;

    // Default (package-private) field
    int defaultNumber = 40;

    // Public method
    public void publicMethod() {
        System.out.println("Public method called");
    }

    // Private method
    private void privateMethod() {
        System.out.println("Private method called");
    }

    // Protected method
    protected void protectedMethod() {
        System.out.println("Protected method called");
    }

    // Default (package-private) method
    void defaultMethod() {
        System.out.println("Default method called");
    }

    public static void main(String[] args) {
        AccessModifier example = new AccessModifier();

        // Accessing public members
        System.out.println("Public Number: " + example.publicNumber);
        example.publicMethod();

        // Accessing private members (Not allowed outside the class)
        System.out.println("Private Number: " + example.privateNumber);
        example.privateMethod();

        // Accessing protected members (Allowed within the same package or through inheritance)
        System.out.println("Protected Number: " + example.protectedNumber);
        example.protectedMethod();

        // Accessing default (package-private) members (Allowed within the same package)
        System.out.println("Default Number: " + example.defaultNumber);
        example.defaultMethod();
    }
}
