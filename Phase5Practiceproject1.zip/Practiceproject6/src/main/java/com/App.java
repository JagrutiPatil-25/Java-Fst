package com;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;

public class App {

    public static void main(String[] args) {
        // Set the path to the Microsoft Edge WebDriver executable
        System.setProperty("webdriver.edge.driver", "D:\\msedgedriver.exe");

        // Create a new instance of the EdgeDriver
        WebDriver driver = new EdgeDriver();

        // Maximize the browser window
        driver.manage().window().maximize();

        // Navigate to Amazon website
        driver.get("https://www.amazon.in/");

        // Take a screenshot
        takeScreenshot(driver, "D:\\1.png");

        // Perform some actions (e.g., search for "samsung" and click on a result)
        WebElement searchBox = driver.findElement(By.id("twotabsearchtextbox"));
        searchBox.sendKeys("samsung");
        searchBox.submit();

        // Take another screenshot after performing actions
        takeScreenshot(driver, "D:\\2.png");

        // Close the browser
        driver.quit();
    }

    // Method to take a screenshot
    public static void takeScreenshot(WebDriver driver, String filePath) {
        File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(screenshotFile, new File(filePath));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
