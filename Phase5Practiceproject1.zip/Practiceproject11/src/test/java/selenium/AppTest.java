package selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class AppTest {

	private WebDriver driver;
    SoftAssert soft = new SoftAssert();

    @BeforeTest
    public void beforeTest() {
   
    	System.setProperty("webdriver.edge.driver", "D:\\msedgedriver.exe");
		WebDriver driver = new EdgeDriver();
    }

    @Test
    public void testEasy() {
        driver.get("https://www.facebook.com");
        String title = driver.getTitle();
        soft.assertEquals(title, "Facebook – log in or sign up");
        soft.assertAll();  // This is necessary to ensure all soft assertions are checked
    }

    @AfterTest
    public void afterTest() {
        driver.quit();
    }
}
