package com.parallel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class ParallelTestsTest {

  @Test
  public void mainTest() {
    throw new RuntimeException("Test not implemented");
  }
  WebDriver driver;
  @Test(groups="Chrome")
  public void LaunchChrome() {
	  System.setProperty("webdriver.edge.driver", "D:\\msedgedriver.exe");
		WebDriver driver = new EdgeDriver();
		 driver.manage().window().maximize();
      driver.get("https://www.facebook.com");
      try {
          Thread.sleep(2000);
      } catch (Exception e) {
          e.printStackTrace();
      }
  }
  @Test(groups="Chrome", dependsOnMethods="LaunchChrome")
  public void TryFacebook1() {
      System.out.println(Thread.currentThread().getId());
      driver.findElement(By.id("email")).sendKeys("ravi10thstudent@gmail.com");
      driver.findElement(By.id("pass")).sendKeys("12345");
      driver.findElement(By.id("loginbutton")).click();
  }
  
  @Test(groups="Firefox")
  public void LaunchFirefox() {
      System.setProperty("webdriver.gecko.driver", "./Resources/geckodriver.exe");
      driver = new FirefoxDriver();
      driver.get("https://www.facebook.com");
      try {
          Thread.sleep(4000);
      } catch (Exception e) {
          e.printStackTrace();
      }
  }}
