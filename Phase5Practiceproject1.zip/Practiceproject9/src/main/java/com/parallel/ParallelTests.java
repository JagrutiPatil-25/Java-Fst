package com.parallel;

import org.openqa.selenium.WebDriver;

import junit.framework.Test;

public class ParallelTests {
	 public static void main( String[] args )
	    {
	        System.out.println( "Hello World!" );
	    }
}
