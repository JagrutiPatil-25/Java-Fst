package com;

public class Assertion {
    
	 public static void main( String[] args )
	    {
	        System.out.println( "Hello World!" );
	    }
    
  

	

}
