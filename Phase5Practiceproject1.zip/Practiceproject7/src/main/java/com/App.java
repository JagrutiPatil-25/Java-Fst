package com;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class App {

	public static void main(String[] args) throws InterruptedException, IOException {
		System.setProperty("webdriver.edge.driver", "D:\\msedgedriver.exe");
		WebDriver wd = new EdgeDriver();
		wd.manage().window().maximize();
		
		//go to browser and open this url 
		wd.get("https://www.ilovepdf.com/pdf_to_word");
		//pickfiles
		wd.findElement(By.id("pickfiles")).click();
		
		Runtime.getRuntime().exec("D:\\UploadFile.exe");
		
		Thread.sleep(2000);
		wd.findElement(By.id("processTask")).click();
		//wd.close();
		
	

	}
}
