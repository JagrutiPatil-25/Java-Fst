package com.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.method.support.ModelAndViewContainer;
import org.springframework.web.servlet.ModelAndView;


import com.entity.User;
import com.service.UserService;


@Controller
public class UserController {

    @Autowired
    UserService userService;

    @RequestMapping(value = "findAllUser", method = RequestMethod.GET)
    public ModelAndView findAllUser(HttpSession hs) {
        List<User> listOfUser = userService.findAllUser();
        hs.setAttribute("users", listOfUser);
        ModelAndView mav = new ModelAndView();
        mav.setViewName("user.jsp");
        return mav;
    }

    @RequestMapping(value = "storeUser", method = RequestMethod.POST)
    public ModelAndView storeUser(HttpServletRequest req, User user, HttpSession hs) {
        String name = req.getParameter("uname");
        String add = req.getParameter("addr");

        user.setUname(name);
        user.setAddr(add);

        String result = userService.storeUser(user);
        ModelAndView mav = new ModelAndView();

        mav.addObject("msg", result);
        List<User> listOfUser = userService.findAllUser();
        hs.setAttribute("users", listOfUser);
        mav.setViewName("user.jsp");
        return mav;
    }

    @RequestMapping(value = "updateUser", method = RequestMethod.GET)
    public ModelAndView updateUser(HttpServletRequest req, HttpSession hs) {
        String idParam = req.getParameter("id");
        ModelAndView mav = new ModelAndView();

        if (idParam != null && !idParam.isEmpty()) {
            int id = Integer.parseInt(idParam);
            System.out.println("user id is " + id);

            mav.addObject("flag", true);
            User u = userService.findUser(id);
            mav.addObject("user", u);

            List<User> listOfUser = userService.findAllUser();
            hs.setAttribute("users", listOfUser); // Fix attribute name here
            mav.setViewName("user.jsp");
        } else {
            // Handle the case where "id" parameter is null or empty
            mav.setViewName("Update.jsp");
        }

        return mav;
    }

    @RequestMapping(value = "updateUserFromDb", method = RequestMethod.GET)
    public ModelAndView updateUserFromDb(HttpServletRequest req, User user, HttpSession hs) {
        String idParam = req.getParameter("id");
        String name = req.getParameter("uname");
        String add = req.getParameter("addr");

        ModelAndView mav = new ModelAndView();

        if (idParam != null && !idParam.isEmpty()) {
            int id = Integer.parseInt(idParam);

            user.setUname(name);
            user.setAddr(add);

            String result = userService.storeUser(user);

            mav.addObject("flag", false);
            User u = userService.findUser(id);
            mav.addObject("user", u);

            List<User> listOfAllUser = userService.findAllUser();
            hs.setAttribute("users", listOfAllUser);
            mav.setViewName("user.jsp");
        } else {
            // Handle the case where "id" parameter is null or empty
            mav.setViewName("Update.jsp");
        }

        return mav;
    }
}
