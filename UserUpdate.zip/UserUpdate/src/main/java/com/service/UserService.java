package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.dao.UserDao;
import com.entity.User;

@Service
public class UserService {
	@Autowired
	UserDao userDao;
	
	public String storeUser(User user) {
		if(userDao.storeUser(user)>0) {
			return "User stored successfully";
		}else {
			return "User didn't store";
		}
	}
	

	public List<User> findAllUser() {
		return userDao.findAllUser();
	}
	
	public User findUser(int id) {
		return userDao.findUser(id);
	}

}
