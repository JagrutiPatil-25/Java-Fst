package com.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.entity.User;


@Repository
public class UserDao {

	@Autowired
	SessionFactory sf;
	
	public int storeUser(User user) {
		try {
			Session session = sf.openSession();
			Transaction tran = session.getTransaction();
			tran.begin();
				session.save(user);
			tran.commit();
			return 1;
		} catch (Exception e) {
			System.err.println(e);
			return 0;
		}
	}
	public User findUser(int id) {
		try {
			Session session = sf.openSession();
			User u = session.find(User.class, id);
			return u;
		} catch (Exception e) {
			System.err.println(e);
		}
		return null;
	}
	public List<User> findAllUser() {
		Session session = sf.openSession();
		TypedQuery<User> qry = session.createQuery("from User");
		List<User> listOfUser = qry.getResultList();
		return listOfUser;
	}
	
}
