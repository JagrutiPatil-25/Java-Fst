package com;

public class Authentication {
    public boolean authenticateUser(String username, String password) {
        return "Jagruti".equals(username) && "Jag@123".equals(password);
    }
}
