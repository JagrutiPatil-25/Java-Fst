package com;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class AuthenticationTest {

    @Test
    public void testAuthenticateUserValidCredentials() {
        Authentication authentication = new Authentication();
        assertTrue(authentication.authenticateUser("Jagruti", "Jag@123"));
    }

    @Test
    public void testAuthenticateUserInvalidCredentials() {
        Authentication authentication = new Authentication();
        assertFalse(authentication.authenticateUser("invalidUser", "invalidPassword"));
    }
}
