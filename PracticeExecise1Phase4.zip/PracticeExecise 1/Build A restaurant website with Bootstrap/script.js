

$(document).ready(function() {
    // Smooth scrolling for anchor links
    $('a[href^="#"]').on('click', function(event) {
        event.preventDefault();

        var target = this.hash;
        var $target = $(target);

        $('html, body').animate({
            'scrollTop': $target.offset().top
        }, 1000, 'swing');
    });

    // Handling form submission
    $("#contactForm").submit(function(e) {
        e.preventDefault();

        // Collect form data
        var formData = {
            name: $("#name").val(),
            email: $("#email").val(),
            message: $("#message").val()
        };

       
        
        if (!formData.name || !formData.email || !formData.message) {
            alert("Please fill in all fields.");
            return;
        }

        // Dummy AJAX request (replace with actual server-side logic)
        $.ajax({
            type: "POST",
            url: "submit_form.php", // Replace with your server-side script
            data: formData,
            success: function(response) {
                // Handle success response
                alert("Form submitted successfully!");
                // Optionally, you can clear the form fields
                $("#name, #email, #message").val('');
            },
            error: function(error) {
                // Handle error response
                alert("Error submitting form. Please try again later.");
            }
        });
    });

    // Add more JQuery code as needed
});
