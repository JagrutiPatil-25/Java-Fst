public class OuterClass {

    // Inner class
    public class InnerClass {
        public void display() {
            System.out.println("Inside InnerClass");
        }
    }

    public static void main(String[] args) {
        // Creating an instance of the outer class
        OuterClass outerInstance = new OuterClass();

        // Creating an instance of the inner class using the outer instance
        InnerClass innerInstance = outerInstance.new InnerClass();

        // Calling a method of the inner class
        innerInstance.display();

        // Anonymous inner class without interface
        OuterClass anonymousInstance = new OuterClass() {
            // Override the display method directly in the anonymous inner class
            public void display() {
                System.out.println("Inside Anonymous Inner Class");
               
            }
        };
        anonymousInstance.display();
    }

	protected void display() {
		// TODO Auto-generated method stub
		
	}
}
