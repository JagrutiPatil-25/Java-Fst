// app.js

// Sample data structure to store team members
const teamMembers = [];

// Function to add a team member
function addTeamMember(name, role, salary) {
    const member = {
        name: name,
        role: role,
        salary: salary
    };

    teamMembers.push(member);
    console.log(`Team member added: ${name} Specific Team ${role}`);
}

// Function to calculate the annual budget of the team
function calculateTeamBudget() {
    let totalBudget = 0;

    // Summing up the salaries of all team members
    for (const member of teamMembers) {
        totalBudget += member.salary;
    }

    return totalBudget;
}

// Sample team members
addTeamMember("John Doe", "Developer", 80000);
addTeamMember("Jane Smith", "Designer", 70000);
addTeamMember("Bob Johnson", "QA Engineer", 75000);

// Calculate and display the team's annual budget
const annualBudget = calculateTeamBudget();
console.log(`Team's Annual Budget: $${annualBudget}`);
