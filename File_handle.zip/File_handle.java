package Practiceproject3;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class ReadWrite {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Specify the file path
        String filePath = "sample.txt";

        // Write to the file
        writeToFile(filePath, "Hello, this is a sample text.");

        // Read from the file
        System.out.println("Contents of the file:");
        readFromFile(filePath);

        // Append to the file
        System.out.print("\nEnter text to append to the file: ");
        String textToAppend = scanner.nextLine();
        appendToFile(filePath, textToAppend);

        // Read again after appending
        System.out.println("\nContents of the file after appending:");
        readFromFile(filePath);

        // Close the scanner
        scanner.close();
    }

    private static void writeToFile(String filePath, String content) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write(content);
            System.out.println("Content successfully written to the file.");
        } catch (IOException e) {
            System.err.println("Error writing to the file: " + e.getMessage());
        }
    }

    private static void readFromFile(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.err.println("Error reading from the file: " + e.getMessage());
        }
    }

    private static void appendToFile(String filePath, String contentToAppend) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
            writer.newLine(); // Start a new line before appending
            writer.write(contentToAppend);
            System.out.println("Content successfully appended to the file.");
        } catch (IOException e) {
            System.err.println("Error appending to the file: " + e.getMessage());
        }
    }
}

