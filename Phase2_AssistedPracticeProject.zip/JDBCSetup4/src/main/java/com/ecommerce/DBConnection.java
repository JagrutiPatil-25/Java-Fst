package com.ecommerce;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.cj.xdevapi.Statement;

public class DBConnection implements AutoCloseable {

    private Connection connection;

    public DBConnection(String url, String userId, String password) throws ClassNotFoundException, SQLException {
    	Class.forName("com.mysql.cj.jdbc.Driver");	
		//System.out.println("Driver loaded successfully");
		
		Connection con  = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root" ,"1198");
		//System.out.println("Connected successfully");
		java.sql.Statement stmt  = con.createStatement();
    }

    public Connection getConnection() {
        return connection;
    }

    @Override
    public void close() throws Exception {
        // Close the database connection when this object is closed
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }
}
