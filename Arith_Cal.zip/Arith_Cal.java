package Practiceproject;

import java.util.Scanner;

public class Calculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Simple Arithmetic Calculator");
        System.out.println("----------------------------");

        while (true) {
            // Input two numbers
            System.out.print("Enter the first number: ");
            double num1 = scanner.nextDouble();

            System.out.print("Enter the second number: ");
            double num2 = scanner.nextDouble();

            int choice = 0; // Move the declaration outside of the inner loop
            double result = 0;

            // Loop for the operation choice
            while (true) {
                System.out.println("\nChoose an operation:");
                System.out.println("1. Addition (+)");
                System.out.println("2. Subtraction (-)");
                System.out.println("3. Multiplication (*)");
                System.out.println("4. Division (/)");

                System.out.print("Enter the operation number: ");
                choice = scanner.nextInt();

                if (choice >= 1 && choice <= 4) {
                    break; // Exit the loop if a valid choice is made
                } else {
                    System.out.println("Invalid choice. Please choose a number between 1 and 4.");
                }
            }

            switch (choice) {
                case 1:
                    result = num1 + num2;
                    break;
                case 2:
                    result = num1 - num2;
                    break;
                case 3:
                    result = num1 * num2;
                    break;
                case 4:
                    if (num2 != 0) {
                        result = num1 / num2;
                    } else {
                        System.out.println("Cannot divide by zero.");
                        continue; // Start a new iteration of the outer loop
                    }
                    break;
            }

            System.out.println("Result: " + result);

            // Ask the user if they want to perform another calculation
            System.out.print("Do you want to perform another calculation? (yes/no): ");
            String repeat = scanner.next().toLowerCase();

            if (!repeat.equals("yes")) {
                System.out.println("Calculator closed. Goodbye!");
                break; // Exit the outer loop if the user does not want to perform another calculation
            }
        }

        scanner.close();
    }
}
