public class MethodExample {

    // Method overloading with different parameter types
    public int add(int a, int b) {
        System.out.println("Method 1 - int parameters");
        return a + b;
    }

    public double add(double a, double b) {
        System.out.println("Method 2 - double parameters");
        return a + b;
    }

    // Method overloading with different number of parameters
    public int add(int a, int b, int c) {
        System.out.println("Method 3 - three int parameters");
        return a + b + c;
    }

    // Method overloading with different order of parameters
    public String concatenate(String str1, String str2) {
        System.out.println("Method 4 - String parameters");
        return str1 + str2;
    }

    public String concatenate(String str1, int num) {
        System.out.println("Method 5 - String and int parameters");
        return str1 + num;
    }

    // Method demonstrating call-by-value behavior
    public void modifyValue(int value) {
        System.out.println("Inside modifyValue method - Before modification: " + value);
        value = value * 2;
        System.out.println("Inside modifyValue method - After modification: " + value);
    }

    public static void main(String[] args) {
    	MethodExample verifier = new MethodExample();

        // Method overloading examples
        System.out.println("Result 1: " + verifier.add(5, 7));
        System.out.println("Result 2: " + verifier.add(3.5, 4.2));
        System.out.println("Result 3: " + verifier.add(2, 4, 6));
        System.out.println("Result 4: " + verifier.concatenate("Hello", " World!"));
        System.out.println("Result 5: " + verifier.concatenate("Number: ", 42));

        // Call-by-value example
        System.out.println("Call by value Example");
        int originalValue = 10;
        System.out.println("Outside modifyValue method - Before modification: " + originalValue);
        verifier.modifyValue(originalValue);
        System.out.println("Outside modifyValue method - After modification: " + originalValue);
    }
}
